# SA Calculator V19.0.0 — Final Android Build Outputs

The GitHub Actions workflow builds and verifies:

- Debug APK: `app/build/outputs/apk/debug/app-debug.apk`
- Unsigned release APK: `app/build/outputs/apk/release/app-release-unsigned.apk`
- Release AAB: `app/build/outputs/bundle/release/app-release.aab`

The workflow uses the preinstalled Android SDK on `ubuntu-24.04`, resolves `sdkmanager` from `latest` or `16.0`, installs Android API `37.0`, Build Tools `36.0.0`, CMake `3.22.1`, and NDK `28.2.13676358`, and validates required source files before building.

The release APK and AAB are unsigned by design. Production distribution requires signing with a keystore that must not be committed to the repository.
