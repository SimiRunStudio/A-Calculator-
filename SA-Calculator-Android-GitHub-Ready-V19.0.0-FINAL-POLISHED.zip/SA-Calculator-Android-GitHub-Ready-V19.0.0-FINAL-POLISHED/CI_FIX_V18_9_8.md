# SA Calculator Android V18.9.8 CI Fix

The GitHub Actions Ubuntu 24.04 image publishes Android API 37 as the SDK package `platforms;android-37.0`, not `platforms;android-37`.

The workflow now:

1. Resolves the preinstalled sdkmanager without `android-actions/setup-android`.
2. Installs `platforms;android-37.0`.
3. Creates the compatibility path `platforms/android-37 -> android-37.0` for Gradle/AGP target resolution.
4. Continues with Build Tools 36.0.0, CMake 3.22.1, and NDK 28.2.13676358.

This addresses the `Failed to find package 'platforms;android-37'` CI error.
