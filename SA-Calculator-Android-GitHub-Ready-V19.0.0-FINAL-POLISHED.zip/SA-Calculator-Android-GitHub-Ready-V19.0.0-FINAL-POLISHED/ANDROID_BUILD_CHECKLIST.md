# Android / GitHub release checklist

- [ ] Create GitHub repository
- [ ] Upload/push this project to `main`
- [ ] Confirm Actions workflow starts
- [ ] Confirm `Android APK` workflow completes
- [ ] Download debug APK artifact
- [ ] Install debug APK on an Android test device/emulator
- [ ] Smoke-test all 28 tools
- [ ] Test History / Favorites persistence
- [ ] Test compact/high-contrast preferences
- [ ] Test rotation policy (portrait lock)
- [ ] Test release APK separately
- [ ] For public distribution, configure signing outside source control
- [ ] Never commit keystore files, passwords, API keys, or tokens
