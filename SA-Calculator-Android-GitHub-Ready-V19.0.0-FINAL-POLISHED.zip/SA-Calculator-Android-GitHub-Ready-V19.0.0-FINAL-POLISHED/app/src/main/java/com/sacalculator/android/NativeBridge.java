package com.sacalculator.android;

public final class NativeBridge {
    static { System.loadLibrary("sa_calculator"); }
    private NativeBridge() {}
    public static native String[] registry();
    public static native String run(String tool, String[] keys, String[] values);
    public static native String graph(String expression, double xmin, double xmax);
}
