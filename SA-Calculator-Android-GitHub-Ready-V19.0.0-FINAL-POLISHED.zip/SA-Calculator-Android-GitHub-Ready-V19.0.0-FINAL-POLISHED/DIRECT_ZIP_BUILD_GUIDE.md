# Direct ZIP Build

This project is prepared for both GitHub layouts:

1. Extracted project files at repository root.
2. A single `.zip` uploaded to repository root.

The workflow detects the layout automatically, extracts the ZIP when necessary, finds the Gradle project, then builds:
- Debug APK
- Unsigned release APK
- Release AAB

Do not commit signing keys, keystore passwords, API keys, or other secrets.
